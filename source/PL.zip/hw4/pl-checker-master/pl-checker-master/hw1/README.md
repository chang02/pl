# HW1
## How to use
1. 구현한 exercise 파일들을 `ex1.ml` ~ `ex4.ml` 으로 복사하거나 새로 작성합니다.
2. `check`를 이용하여 검사합니다.
    - `./check` : 모든 exercise를 한번에 검사합니다.
    - `./check <num>` : exercise\<num\>을 검사합니다.

