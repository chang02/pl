> SNU 4190.310 Programming Languages

# Rozetta

## 컴파일 및 실행 방법

 `sm5.ml`에는 sm5언어와 실행기, `sonata.ml`에는 sonata 언어와 실행기가 정의되어 있습니다.
 아래와 같이 실행하면, 주어진 sm5 프로그램을 여러분이 작성하신 rozetta 번역기에 따라 번역하고 Sonata 기계로 실행합니다.
```
  $ make
  $ ./run examples/test1.sm5
```

## SM5 기계로 실행하기

주어진 SM5 프로그램을 SM5 기계로 실행한 결과를 다음과 같이 확인할 수 있습니다.
번역이 제대로 되었다면, Sonata 기계로 실행한 결과와 SM5 기계로 실행한 결과가 같아야 합니다.
```
 $ ./run -sm5 examples/test1.sm5
```

## 번역된 Sonata 프로그램 출력하기

 주어진 SM5 프로그램을 Sonata로 번역한 결과를 `-psonata` 옵션을 통해 출력할 수 있습니다.
```
 $ ./run -psonata examples/test1.sm5
```

## SM5/Sonata 기계 위에서 디버그 모드로 실행하기

 주어진 프로그램을 SM5나 Sonata 기계로 실행할 때, 매 스텝마다 기계 상태를 출력합니다.
```
 $ ./run -debug examples/test1.sm5
```


## 숙제 제출 관련
 `rozetta.ml` 파일에 있는 `trans` 함수를 완성하시고 그 파일만 제출해 주세요.

---
최웅식 <wschoi@ropas.kaist.ac.kr> <br>
신재호 <netj@ropas.snu.ac.kr> <br>
김덕환 <dk@ropas.snu.ac.kr> <br>
오학주 <pronto@ropas.snu.ac.kr> <br>
박대준 <pudrife@ropas.snu.ac.kr> <br>
이희종 <ihji@ropas.snu.ac.kr> <br>
정영범 <dreameye@ropas.snu.ac.kr> <br>
오학주 <pronto@ropas.snu.ac.kr> <br>
허기홍 <khheo@ropas.snu.ac.kr> <br>
조성근 <skcho@ropas.snu.ac.kr> <br>
윤용호 <yhyoon@ropas.snu.ac.kr> <br>
김진영 <jykim@ropas.snu.ac.kr> <br>
15 최재승 <jschoi@ropas.snu.ac.kr> <br>
17 이동권 <dklee@ropas.snu.ac.kr> <br>
