(* testcase 10 : pair *)

((fn x => (x, 3)) 2).1

(* Output : 2 *)
