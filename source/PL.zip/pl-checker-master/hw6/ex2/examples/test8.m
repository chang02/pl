(* testcase 8 : Num *)

123
