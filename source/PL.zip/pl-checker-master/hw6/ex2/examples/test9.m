(* testcase 9 : Fn App *)

(fn x => x + 100) 5
