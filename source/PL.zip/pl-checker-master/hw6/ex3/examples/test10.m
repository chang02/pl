(* testcase 10 : M.CONST *)

write 123;
write true;
write false;
write "true";
write "string"
