# HW7
## How to use
### 6-1 : let-polymorphic type checker (`ex1/`)
1. 구현한 `poly_checker.ml`을 복사하거나 뼈대코드 `poly_checker.ml.orig`을 `poly_checker.ml`로 복사 한 후 구현합니다.
2. `./check` 명령어를 통해 테스트케이스를 실행합니다.

- `examples/test<num>.m` : 테스트케이스
- `examples/test<num>.ans` : 정답
- `examples/test<num>.out` : 출력
