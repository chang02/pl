let val f = (fn x => 2) in (f f) end
