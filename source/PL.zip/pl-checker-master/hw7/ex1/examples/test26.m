(fn x => x x) (fn x => 2)
